import rl from "readline-sync";
import fightersData from "./fighters.json";

// 1. Interfaces definiëren voor Type Safety
interface Club {
  id: string;
  name: string;
  city: string;
  headCoach: string;
  foundedYear: number;
  logoUrl: string;
}

interface Fighter {
  id: string;
  name: string;
  description: string;
  age: number;
  isActive: boolean;
  birthDate: string;
  imageUrl: string;
  weightClass: string;
  fightStyle: string;
  skills: string[];
  club: Club;
}

// 2. Data inladen
const fighters: Fighter[] = fightersData;
const menuItems: string[] = ["View all data", "Filter by ID"];
let running: boolean = true;

// 3. Hoofdmenu (Main Loop)
console.log("Welcome to the JSON data viewer!");

while (running) {
  const answer = rl.keyInSelect(menuItems, "Please enter your choice");

  if (answer === 0) {
    showAllFighters();
  } else if (answer === 1) {
    filterById();
  } else if (answer === -1) {
    console.log("Exiting... Goodbye!");
    running = false;
  }
}

// 4. Functies
function showAllFighters() {
  console.log("\n--- ALL FIGHTERS ---");
  fighters.forEach((f) => printFighter(f));
}

function filterById() {
  const idInput = rl.question("Please enter the ID you want to filter by: ").toUpperCase();
  const foundFighter = fighters.find((f) => f.id === idInput);

  if (foundFighter) {
    printFighter(foundFighter);
  } else {
    console.log(`\n[!] No fighter found with ID: ${idInput}`);
  }
}


function printFighter(f: Fighter) {
  console.log(`\n- ${f.name} (${f.id})`);
  console.log(`  - Description: ${f.description}`);
  console.log(`  - Age: ${f.age}`);
  console.log(`  - Active: ${f.isActive}`);
  console.log(`  - Birthdate: ${f.birthDate}`);
  console.log(`  - Image: ${f.imageUrl}`);
  console.log(`  - Weight Class: ${f.weightClass}`);
  console.log(`  - Fight Style: ${f.fightStyle}`);
  console.log(`  - Skills: ${f.skills.join(", ")}`);
  console.log(`  - Club: ${f.club.name}`);
  console.log(`    - Name: ${f.club.name}`);
  console.log(`    - Head Coach: ${f.club.headCoach}`);
  console.log(`    - City: ${f.club.city}`);
  console.log(`    - Founded: ${f.club.foundedYear}`);
  console.log(`    - Logo: ${f.club.logoUrl}`);
}